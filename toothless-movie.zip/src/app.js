import 'regenerator-runtime'
import './styles/style.css'
import './script/component/app-bar.js'
import './script/component/search-bar.js'
import main from './script/view/main.js'
import 'bootstrap/dist/css/bootstrap.min.css'

main()
